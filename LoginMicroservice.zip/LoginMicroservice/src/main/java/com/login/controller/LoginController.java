package com.login.controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.login.exception.BusinessException;
import com.login.service.LoginService;
import com.login.util.MyConstants;
import com.login.vo.CredResponse;
import com.login.vo.Credential;

import io.micrometer.common.util.StringUtils;
import jakarta.validation.Valid;
 
@RestController
@RequestMapping("/login/")
public class LoginController {
	
	@Autowired
	private LoginService loginService;
	
	@PostMapping(path = "registeruser")
	public ResponseEntity<CredResponse> registerUser(@Valid @RequestBody Credential cred)
	{
			if(cred.getUserId().isEmpty())
			{
				throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, MyConstants.CHECK_LOGIN_INFO);
			}
			 CredResponse registerUser = loginService.registerUser(cred);
		
		return new ResponseEntity<CredResponse>(registerUser, HttpStatus.OK);
	}
	
	@GetMapping("loginUser")
	public ResponseEntity<CredResponse> userLogin(@RequestParam(name = "userId", required = true) String userId,
			@RequestParam(name = "password", required = true) String password) 
	{
		Credential cred = new Credential();
		cred.setUserId(userId);
		cred.setPassword(password);
		
		CredResponse userLogin = loginService.userLogin(cred);
		
		return new ResponseEntity<CredResponse>(userLogin, HttpStatus.OK);
	}
		
	@GetMapping("getPassword/{emailId}")
	
	public ResponseEntity<String> getPassByEmailId(@PathVariable (name = "emailId")String emailId)
	{
		String passwordByEmail = loginService.getPasswordByEmail(emailId);
		return new ResponseEntity<String>(passwordByEmail,HttpStatus.ACCEPTED);
	}
	
	@GetMapping(path = "getrole/{userId}")
	public ResponseEntity<String> getUserRole(@PathVariable(name = "userId") String userId) {
		String response = loginService.getUserRole(userId);
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}
 
 
}

package com.login.dao;
 
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import com.login.exception.BusinessException;
import com.login.util.MyConstants;
import com.login.vo.CredResponse;
import com.login.vo.Credential;
 
 
@Component
public class LoginDao {
	@Autowired
	private NamedParameterJdbcTemplate dBTemplate;
	
	public CredResponse registerUser(Credential cred) {
		
		  String queryCheckEmail = "SELECT COUNT(*) FROM user_details WHERE EMAIL_ID = :emailId";
		    Map<String, Object> checkEmail = new HashMap<>();
		    checkEmail.put("emailId", cred.getEmailId());
		    int count = dBTemplate.queryForObject(queryCheckEmail, checkEmail, Integer.class);
		 
		    if (count > 0) {
		        throw new BusinessException(HttpStatus.BAD_REQUEST, "User with this email already exists.");
		    }
		    
		    
		    String queryCheckUserId = "SELECT COUNT(*) FROM user_details WHERE USER_ID = :userId";
		    Map<String, Object> checkUserId = new HashMap<>(); 
		    checkUserId.put("userId", cred.getUserId()); 
		    int countUserId = dBTemplate.queryForObject(queryCheckUserId, checkUserId, Integer.class);
		    if (countUserId > 0) 
		    {
		    	throw new BusinessException(HttpStatus.BAD_REQUEST, "User with this user ID already exists.");
		    	}
		
		String query = "INSERT INTO user_details (USER_ID , PASSWORD ,FIRST_NAME, ADDRESS,LAST_NAME,EMAIL_ID,MOBILE_NUMBER,ROLE)"
				+ "VALUES (:userId,:password, :firstName ,:address, :lastName, :emailid, :mobilenumber,:role)";
		Map<String, String> param = new HashMap<>();
		param.put("userId", cred.getUserId());
		param.put("password", cred.getPassword());
		param.put("firstName", cred.getFirstName());
		param.put("address", cred.getAddress());
		param.put("lastName", cred.getLastName());
		param.put("emailid", cred.getEmailId());
		param.put("mobilenumber", cred.getMobileNumber());
		param.put("role", cred.getRole());
		dBTemplate.update(query, param);
		String query1 = "select * from User_Details where USER_ID=:userId";
		
		Map<String, String> param1 = new HashMap<>();
		param1.put("userId", cred.getUserId());
		
		List<Credential> userList = dBTemplate.query(query1, param,
				new BeanPropertyRowMapper<Credential>(Credential.class));
		if (userList.size() == 0) {
			throw new BusinessException(HttpStatus.BAD_REQUEST, MyConstants.CHECK_LOGIN_INFO);
		}
		return new CredResponse(HttpStatus.OK, "Registration SucessFully..", userList.get(0));
	}

	public CredResponse userLogin(Credential cred) {
		
 		String query = "select * from User_Details where USER_ID=:userId and PASSWORD=:password";
		Map<String, String> param = new HashMap<>();
		param.put("userId", cred.getUserId());
		param.put("password", cred.getPassword());
		List<Credential> userList = dBTemplate.query(query, param,
				new BeanPropertyRowMapper<Credential>(Credential.class));
 
//		if (userList.size() == 0) {
//			throw new BusinessException(HttpStatus.BAD_REQUEST, MyConstants.CHECK_LOGIN_INFO);
//		}
// 
		return new CredResponse(HttpStatus.OK, MyConstants.VALIDATE_LOGIN, userList.get(0));
	}

	public String findPasswordByEmail(String emailId) {
		
		String query = "select password from User_Details where EMAIL_ID=:emailid";
		Map<String, String> param = new HashMap<>();
		param.put("emailid", emailId);
		List<Credential> userList = dBTemplate.query(query, param,
				new BeanPropertyRowMapper<Credential>(Credential.class));
 
		Credential cred = userList.get(0);
		String password = cred.getPassword();
 
//		if(userList.size()==0) {
//	
//					throw new  BusinessException(HttpStatus.BAD_REQUEST, "Email is not found in DB.");
//		}
// 
		return password;
		
		
	}

	public String getUserRole(String userId) {
		 
		String query = "SELECT ROLE FROM user_details WHERE USER_ID = :userId";
		Map<String, Object> paramMap = new HashMap<>(); 
		paramMap.put("userId", userId); 
		List<String> roleList = dBTemplate.queryForList(query, paramMap, String.class);
		if (roleList.isEmpty())
		{
			throw new BusinessException(HttpStatus.NOT_FOUND, "User not found with the provided user ID: " + userId);
			}
		
		String query1 = "select role from User_Details where USER_ID=:userId";
		Map<String, String> param = new HashMap<>();
		param.put("userId", userId);
		List<Credential> userList = dBTemplate.query(query1, param,
				new BeanPropertyRowMapper<Credential>(Credential.class));
 
		Credential cred = userList.get(0);
		String response = cred.getRole();
 
		return response;
	}
 
 
}
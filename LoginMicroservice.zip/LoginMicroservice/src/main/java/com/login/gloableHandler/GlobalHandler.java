package com.login.gloableHandler;
 
import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.login.exception.BusinessException;
import com.login.util.MyConstants;
import com.login.vo.CredResponse;
 
@ControllerAdvice
public class GlobalHandler {
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Object> handleMethodArgumentNotValidException(MethodArgumentNotValidException exception)
	{
	Map<String, String> errors = new HashMap<>();
	
	//List<FieldError> listOfErrors = exception.getBindingResult().getAllErrors();
	for (ObjectError fieldError :exception.getBindingResult().getAllErrors()) {
		
		
			String fieledName = ((FieldError) fieldError).getField();
			String errorMsg= fieldError.getDefaultMessage();
			errors.put(fieledName, errorMsg);
		}
		
 
	return new ResponseEntity<Object>(errors, HttpStatus.BAD_REQUEST);
	
	
	}
	
	
	@ExceptionHandler({ BusinessException.class })
	public ResponseEntity<String> handlerLoginException(BusinessException ex) {
 
		return new ResponseEntity<String>(ex.getErrorMesg(),ex.getErroecode());
 
	}
	
	
		
}
 
package com.login.exception;

import org.springframework.http.HttpStatusCode;

import com.login.vo.CredResponse;

public class BusinessException extends RuntimeException {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private HttpStatusCode erroecode;
	private String errorMesg;
	private CredResponse credResponse;
	
	
	public BusinessException(CredResponse credResponse,HttpStatusCode erroecode, String errorMesg ) {
		super();
		this.erroecode = erroecode;
		this.errorMesg = errorMesg;
		this.credResponse = credResponse;
	}
	public BusinessException(HttpStatusCode erroecode, String errorMesg) {
		super();
		this.erroecode = erroecode;
		this.errorMesg = errorMesg;
	}
	public HttpStatusCode getErroecode() {
		return erroecode;
	}
	public void setErroecode(HttpStatusCode erroecode) {
		this.erroecode = erroecode;
	}
	public String getErrorMesg() {
		return errorMesg;
	}
	public void setErrorMesg(String errorMesg) {
		this.errorMesg = errorMesg;
	}
	
	
 
	

 
}
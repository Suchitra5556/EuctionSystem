package com.login.vo;
 
import org.springframework.http.HttpStatus;
 
public class CredResponse {
	
	private HttpStatus statusCode;
	private String statusMessage;
	private Credential credentials;
	
	public CredResponse(HttpStatus statusCode, String statusMessage, Credential credentials) {
		super();
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
		this.credentials = credentials;
	}
 
	public CredResponse(String invalidLogin, HttpStatus badRequest) {
		// TODO Auto-generated constructor stub
	}

	public HttpStatus getStatusCode() {
		return statusCode;
	}
 
	public void setStatusCode(HttpStatus statusCode) {
		this.statusCode = statusCode;
	}
 
	public String getStatusMessage() {
		return statusMessage;
	}
 
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
 
	public Credential getCredentials() {
		return credentials;
	}
 
	public void setCredentials(Credential credentials) {
		this.credentials = credentials;
	}
 
	@Override
	public String toString() {
		return "CredResponse [statusCode=" + statusCode + ", statusMessage=" + statusMessage + ", credentials="
				+ credentials + "]";
	}
	
	
	
	
 
}
 
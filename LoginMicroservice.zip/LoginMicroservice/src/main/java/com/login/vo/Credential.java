package com.login.vo;
 
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
 
@Entity
@Table(name = "UserDetails")
public class Credential {
	
	@Id
	@NotNull(message = "Please Enmter Valid UserId")
	private String userId;
	
	@Pattern(regexp ="^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$" ,message = "Please Enter Valid Password")
	@NotBlank(message = "Password Should not be blank")
	private String password;
	
	@NotBlank(message = "Name Should not be Blank")
	private String firstName;
	
	@NotBlank(message = "lastName Should not be Blank")
	private String lastName;
	
	@Pattern(regexp = "^[0-9]{10}$",message = "Mobile Number Should Have 10 digts..")
	private String mobileNumber;
	
	@NotBlank(message = "Name Should not be Blank")
	private String address;
	
	@Email
	@Pattern(regexp ="[A-Za-z0-9._%+-]+@[A_Za-z0-9.-]+\\.[A-Z|a-z]{2,}$" , message = "Please Enter Email in Valid Format")
	private String emailId;
	
	@NotBlank(message = "Role Should not be Blank")
	private String role;
	
	
	public Credential()
	{
		
	}
	
	public Credential(String userId, String password, String firstName, String lastName, String mobileNumber,
			String address, String emailId, String role) {
		super();
		this.userId = userId;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.address = address;
		this.emailId = emailId;
		this.role = role;
	}
 
	public String getUserId() {
		return userId;
	}
 
	public void setUserId(String userId) {
		this.userId = userId;
	}
 
	public String getPassword() {
		return password;
	}
 
	public void setPassword(String password) {
		this.password = password;
	}
 
	public String getFirstName() {
		return firstName;
	}
 
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
 
	public String getLastName() {
		return lastName;
	}
 
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
 
	public String getMobileNumber() {
		return mobileNumber;
	}
 
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
 
	public String getAddress() {
		return address;
	}
 
	public void setAddress(String address) {
		this.address = address;
	}
 
	public String getEmailId() {
		return emailId;
	}
 
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
 
	public String getRole() {
		return role;
	}
 
	public void setRole(String role) {
		this.role = role;
	}
 
	@Override
	public String toString() {
		return "Credential [userId=" + userId + ", password=" + password + ", firstName=" + firstName + ", lastName="
				+ lastName + ", mobileNumber=" + mobileNumber + ", address=" + address + ", emailId=" + emailId
				+ ", role=" + role + "]";
	}
	
	
	
 
}
 
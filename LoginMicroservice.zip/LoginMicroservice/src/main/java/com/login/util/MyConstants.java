package com.login.util;

public  class MyConstants {
	
	public static final String  CREARED = "Record Stored successfully !..";
	
	public static final String CHECK_LOGIN_INFO="Please Provide Correct UserId";
	
	
	public static final String VALIDATE_LOGIN="login Successfull";
	public static final String REGISTRATION="registration Successfull";
  
	
	public static final String INVALID_LOGIN="Invalid username/password";

	public static String USER_ID_NOT_EXISTS = "uSER iD NOT FOUND UN DB";
	
	

}

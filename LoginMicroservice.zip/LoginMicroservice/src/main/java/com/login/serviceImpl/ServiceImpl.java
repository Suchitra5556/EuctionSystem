package com.login.serviceImpl;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.login.dao.LoginDao;
import com.login.service.LoginService;
import com.login.vo.CredResponse;
import com.login.vo.Credential;

 
@Component
public class ServiceImpl implements LoginService {
	
	@Autowired
	private LoginDao loginDao;
 
	@Override
	public CredResponse registerUser(Credential cred) {
		
			CredResponse registerUser = loginDao.registerUser(cred);
				return registerUser;
			
		}
	
	
	@Override
	public CredResponse userLogin(Credential cred) {
 
		
		CredResponse response = loginDao.userLogin(cred);
		return response;
	}


	@Override
	public String getPasswordByEmail(String emailId) {
		
		 String passwordByEmail = loginDao.findPasswordByEmail(emailId);
		 return passwordByEmail;
		
	}


	@Override
	public String getUserRole(String userId) 
	{
		
		 String userRole = loginDao.getUserRole(userId);
		 return userRole;
	}
 
 
	
}
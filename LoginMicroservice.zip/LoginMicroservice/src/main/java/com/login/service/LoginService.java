
package com.login.service;

import org.springframework.stereotype.Component;
import com.login.vo.CredResponse;
import com.login.vo.Credential;

@Component
public interface LoginService {

	public CredResponse registerUser(Credential cred);

	public CredResponse userLogin(Credential cred);

	public String getPasswordByEmail(String emailId);

	public String getUserRole(String userId);

}
